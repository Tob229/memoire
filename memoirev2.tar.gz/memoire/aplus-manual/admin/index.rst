Course administration
=====================

How to set up the course for students?

.. toctree::

  create_new_instance
  setup
  settings
