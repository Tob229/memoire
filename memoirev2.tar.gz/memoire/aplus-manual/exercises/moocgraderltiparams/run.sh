#!/bin/sh

capture pre /exercise/greet.sh

grade 10/10

