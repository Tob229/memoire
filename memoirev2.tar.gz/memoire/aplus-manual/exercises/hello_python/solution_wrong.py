def hello():
    print("And now for something completely different.")
