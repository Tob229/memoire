from django.apps import AppConfig


class AccountsConfig(AppConfig):
    name = "accounts"
    display_name = "Radar accounts"
