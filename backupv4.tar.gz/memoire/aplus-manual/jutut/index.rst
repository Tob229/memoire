Jutut service for feedback and messaging
========================================

.. toctree::

  introduction
  features_and_hints

.. aplusmeta::
  :introduction: <p><b>Jutut</b> is a tool that enables teachers to <strong>collect feedback continuously</strong> during a course,
    to prompt students to <strong>comment on specific parts of course content</strong>, and
    to encourage <strong>messaging between students and course staff</strong>.</p>
