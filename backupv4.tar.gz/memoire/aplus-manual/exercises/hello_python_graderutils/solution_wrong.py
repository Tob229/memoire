def hello():
    "And now for something completely different."
