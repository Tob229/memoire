def is_prime(x):
    raise Exception
