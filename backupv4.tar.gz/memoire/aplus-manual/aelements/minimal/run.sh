#!/bin/bash

# The input in the text field given by the user is stored
# into a file named input according to the config.yaml.
# Just echo the input given by the user.
capture cat input

grade 0/0
