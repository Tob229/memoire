from django.apps import AppConfig


class StaticfileServerConfig(AppConfig):
    name = 'staticfileserver'
