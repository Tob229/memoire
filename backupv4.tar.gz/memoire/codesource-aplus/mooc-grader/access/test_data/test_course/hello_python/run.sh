#!/bin/bash
capture python3 tests.py
err-to-out
