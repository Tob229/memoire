docker run -it --rm --entrypoint bash run-radar
