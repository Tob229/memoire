Moodle Astra plugin
===================

Moodle Astra plugin is an alternative frontend to A+ courses.

.. toctree::

  introduction

