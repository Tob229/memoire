Active elements
===============

Active elements are widgets embedded into chapters that
may execute asynchronous computations in the grader backend
like exercises.

.. toctree::

  introduction
  octave_examples

