Set up your environment
=======================

.. toctree::

  first_steps
  git
  docker
  editors
  vs_code
  macos


.. aplusmeta::
  :introduction: <h3>Setup your environment</h3>
    <p>In this section we will cover the following topics</p>
