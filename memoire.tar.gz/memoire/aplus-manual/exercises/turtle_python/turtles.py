
def turtles(t):
    pass

if __name__ == "__main__":
    import turtle
    turtles(turtle.Turtle())
    window = turtle.Screen()
    window.exitonclick()
