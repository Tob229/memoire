def is_prime(n):
    """ Return True if n is a prime number, else False. """
    if n < 2:
        return False
    raise NotImplementedError("This exercise is still unsolved.")
