Adding Sphinx extensions
^^^^^^^^^^^^^^^^^^^^^^^^

.. toctree::

  guide
