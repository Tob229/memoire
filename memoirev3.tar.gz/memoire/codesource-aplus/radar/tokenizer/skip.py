def tokenize(source, config):
    """
    Skips the tokenizing with an empty result.

    """
    return ("", [])
