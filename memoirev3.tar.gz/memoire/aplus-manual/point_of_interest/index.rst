Point of Interest
-----------------

Introduction to point of interest summary blocks and Presentation Maker.

.. toctree::

  introduction
  examples
  presentation_maker
