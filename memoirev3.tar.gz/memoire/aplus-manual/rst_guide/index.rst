RST Guide
=========

.. toctree::
  :maxdepth: 2

  get_started
  basic_syntax
  advanced_syntax
  additional_resources_and_cheatsheet

.. aplusmeta::
  :introduction: <h3>The reStructuredText Guide</h3>
    <p>In this section we will cover the following topics</p>
