Interactive code blocks
^^^^^^^^^^^^^^^^^^^^^^^

.. toctree::

  guide
  advanced
