Rubyric
=======

Documentation of Rubyric feedback service.

.. toctree::
  introduction
  getting_started
  rubrics_and_reviews
  roles_and_groups
  example
