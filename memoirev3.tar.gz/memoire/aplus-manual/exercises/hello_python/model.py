def hello():
    return "Hello Python!"
