Little RST hacking
..................

RST is *super easy*! I want to know more.

Here are the results of my latest experiment:

+--------+---------+-----------+----------------+
| sample | catness |  weight   |     sound      |
+========+=========+===========+================+
|   1    |   0.01  |    70     |    Yee-haw!    |
+--------+---------+-----------+----------------+
|   2    |   1.01  |    15     | Where's pizza? |
+--------+---------+-----------+----------------+
|   3    |   0.12  |     5     |      arf.      |
+--------+---------+-----------+----------------+

.. image:: /images/rst-sample.png


