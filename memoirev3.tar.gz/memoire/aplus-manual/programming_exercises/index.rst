Programming exercises
=====================

.. toctree::

  instructions
  hello_world
  graderutils
  personalized_exercises
  debugging_in_container
  radar
  graphics
  web_frontend
  ajax_exercise
  submit_from_git
  grader_lti_params
  designing
