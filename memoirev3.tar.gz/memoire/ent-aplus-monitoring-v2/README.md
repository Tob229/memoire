# ent-aplus-monitoring
Monitoring of ENT Aplus lms with prometheus , grafana 
